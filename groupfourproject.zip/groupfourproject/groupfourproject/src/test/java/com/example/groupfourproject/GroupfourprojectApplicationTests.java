package com.example.groupfourproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupfourprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
