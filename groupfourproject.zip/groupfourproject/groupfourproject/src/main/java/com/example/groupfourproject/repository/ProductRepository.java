package com.example.groupfourproject.repository;
import com.example.groupfourproject.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product,Long> {
    // for some new method like findAll() findById, save() deleteById,
}
