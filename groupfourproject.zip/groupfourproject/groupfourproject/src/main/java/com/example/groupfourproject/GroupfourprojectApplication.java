package com.example.groupfourproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupfourprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroupfourprojectApplication.class, args);
	}

}
